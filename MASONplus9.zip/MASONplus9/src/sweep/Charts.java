package sweep;

public enum Charts {
	NOCHART,TIMESERIES,HISTOGRAM
}
